<?php require 'header.php';?>

  <body>
    <div class="page">
      <!-- Page Header-->
  <?php require 'navbar.php'; ?>

      <!-- Breadcrumbs -->
      <section class="breadcrumbs-custom bg-image context-dark" style="background-image: url(images/bg_3.jpg);">
        <div class="breadcrumbs-custom-inner">
          <div class="container breadcrumbs-custom-container">
            <div class="breadcrumbs-custom-main">
              <h6 class="breadcrumbs-custom-subtitle title-decorated">Teachers</h6>
              <h2 class="breadcrumbs-custom-title">Teachers</h2>
            </div>
            <ul class="breadcrumbs-custom-path">
              <li><a href="index.php">Home</a></li>
              <li class="active">Teachers</li>
            </ul>
          </div>
        </div>
      </section>

      <!-- Who We Are-->
      <section class="section section-lg section-last text-center">
        <div class="container">
          <h3>Our Teachers</h3>
          <div class="row row-50">
            <div class="col-sm-6 col-lg-4">
              <!-- Profile Minimal-->
              <article class="profile-minimal"><img class="profile-minimal-image" src="images/user.jpg" alt="" width="370" height="368"/>
                <div class="profile-minimal-caption">
                  <h4 class="profile-minimal-title">Sam Clarke</h4>
                  <p class="profile-minimal-position">Guitar & Piano Teacher</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4">
              <!-- Profile Minimal-->
              <article class="profile-minimal"><img class="profile-minimal-image" src="images/user.jpg" alt="" width="370" height="368"/>
                <div class="profile-minimal-caption">
                  <h4 class="profile-minimal-title">Kate McMillan</h4>
                  <p class="profile-minimal-position">Piano Teacher</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4">
              <!-- Profile Minimal-->
              <article class="profile-minimal"><img class="profile-minimal-image" src="images/user.jpg" alt="" width="370" height="368"/>
                <div class="profile-minimal-caption">
                  <h4 class="profile-minimal-title">John Thompson</h4>
                  <p class="profile-minimal-position">DJ Classes Teacher</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4">
              <!-- Profile Minimal-->
              <article class="profile-minimal"><img class="profile-minimal-image" src="images/user.jpg" alt="" width="370" height="368"/>
                <div class="profile-minimal-caption">
                  <h4 class="profile-minimal-title">Mary Williams</h4>
                  <p class="profile-minimal-position">Trumpet Teacher</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4">
              <!-- Profile Minimal-->
              <article class="profile-minimal"><img class="profile-minimal-image" src="images/user.jpg" alt="" width="370" height="368"/>
                <div class="profile-minimal-caption">
                  <h4 class="profile-minimal-title">Peter Smith</h4>
                  <p class="profile-minimal-position">Hearing Classes Teacher</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4">
              <!-- Profile Minimal-->
              <article class="profile-minimal"><img class="profile-minimal-image" src="images/user.jpg" alt="" width="370" height="368"/>
                <div class="profile-minimal-caption">
                  <h4 class="profile-minimal-title">Nathalie Porter</h4>
                  <p class="profile-minimal-position">Founder, Vocal Teacher</p>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section>

      <!-- Latest Events-->
      <section class="section section-lg bg-gray-100">
        <div class="container">
          <h3 class="text-center">Latest Events</h3>
          <div class="row row-50 justify-content-center justify-content-lg-start">
            <div class="col-md-10 col-lg-7 wow-outer">
              <!-- Post Block-->
              <article class="post-block bg-gray-700"><img class="post-block-image" src="images/bg_11.jpg" alt="" width="637" height="456"/>
                <div class="post-block-caption">
                  <ul class="post-block-meta">
                    <li class="wow-outer"><span class="wow slideInLeft">by Theresa Barnes</span></li>
                    <li class="wow-outer"><a class="button-winona wow slideInLeft" href="#">Events</a></li>
                    <li class="wow-outer">
                      <time class="wow slideInLeft" datetime="2018">April 2, 2018</time>
                    </li>
                  </ul>
                  <h4 class="post-block-title"><a href="single-blog-post.html">Melody Music School Live DJ Set</a></h4>
                </div>
                <div class="post-block-dummy"></div>
              </article>
            </div>
            <div class="col-md-10 col-lg-5">
              <div class="post-light-group wow-outer">
                <!-- Post Light-->
                <article class="post-light wow slideInLeft">
                  <time class="post-light-time" datetime="2018"><span class="post-light-time-big">29</span><span class="post-light-time-small">April</span></time>
                  <div class="post-light-main">
                    <h4 class="post-light-title"><a href="single-blog-post.html">Melody Music School Live DJ Set</a></h4>
                    <ul class="post-light-meta">
                      <li>by Theresa Barnes</li>
                      <li><a class="button-winona" href="#">Events</a></li>
                    </ul>
                  </div>
                </article>
                <!-- Post Light-->
                <article class="post-light wow slideInLeft">
                  <time class="post-light-time" datetime="2018"><span class="post-light-time-big">30</span><span class="post-light-time-small">April</span></time>
                  <div class="post-light-main">
                    <h4 class="post-light-title"><a href="single-blog-post.html">Performing Popular Songs on Piano</a></h4>
                    <ul class="post-light-meta">
                      <li>by Theresa Barnes</li>
                      <li><a class="button-winona" href="#">Events</a></li>
                    </ul>
                  </div>
                </article>
                <!-- Post Light-->
                <article class="post-light wow slideInLeft">
                  <time class="post-light-time" datetime="2018"><span class="post-light-time-big">2</span><span class="post-light-time-small">May</span></time>
                  <div class="post-light-main">
                    <h4 class="post-light-title"><a href="single-blog-post.html">How to Compose Your First Guitar Melody</a></h4>
                    <ul class="post-light-meta">
                      <li>by Theresa Barnes</li>
                      <li><a class="button-winona" href="#">Events</a></li>
                    </ul>
                  </div>
                </article>
              </div>
              <div class="wow-outer button-outer"><a class="button button-primary button-winona wow slideInDown" href="grid-blog.html">View all posts</a></div>
            </div>
          </div>
        </div>
      </section>

      <!-- Page Footer-->
          <?php require 'footer.php'; ?>