<?php require 'header.php';?>
  <body>
    <div class="page">
      <?php require 'navbar.php'; ?>

      <!-- Breadcrumbs -->
      <section class="breadcrumbs-custom bg-image context-dark" style="background-image: url(images/bg_10.jpg);">
        <div class="breadcrumbs-custom-inner">
          <div class="container breadcrumbs-custom-container">
            <div class="breadcrumbs-custom-main">
              <h6 class="breadcrumbs-custom-subtitle title-decorated">Classes</h6>
              <h2 class="breadcrumbs-custom-title">Classes</h2>
            </div>
            <ul class="breadcrumbs-custom-path">
              <li><a href="index.php">Home</a></li>
              <li class="active">Classes</li>
            </ul>
          </div>
        </div>
      </section>
      <!-- Counters-->
      <section class="section section-lg text-center">
        <div class="container">
          <h3>Some Facts About Our School</h3>
          <p><span class="text-width-1">We have been helping people sharpen their music skills since our foundation. Below are just some facts and numbers from our history that will tell you more about us.</span></p>
          <div class="row row-50">
            <div class="col-6 col-md-3">
              <!-- Counter Minimal-->
              <article class="counter-minimal">
                <div class="counter-minimal-icon linearicons-trophy2"></div>
                <div class="counter-minimal-main">
                  <div class="counter">12</div>
                </div>
                <h5 class="counter-minimal-title">International Awards</h5>
              </article>
            </div>
            <div class="col-6 col-md-3">
              <!-- Counter Minimal-->
              <article class="counter-minimal">
                <div class="counter-minimal-icon linearicons-music-note2"></div>
                <div class="counter-minimal-main">
                  <div class="counter">238</div>
                </div>
                <h5 class="counter-minimal-title">Satisfied Students</h5>
              </article>
            </div>
            <div class="col-6 col-md-3">
              <!-- Counter Minimal-->
              <article class="counter-minimal">
                <div class="counter-minimal-icon linearicons-star"></div>
                <div class="counter-minimal-main">
                  <div class="counter">19</div>
                </div>
                <h5 class="counter-minimal-title">Years of Experience</h5>
              </article>
            </div>
            <div class="col-6 col-md-3">
              <!-- Counter Minimal-->
              <article class="counter-minimal">
                <div class="counter-minimal-icon linearicons-users2"></div>
                <div class="counter-minimal-main">
                  <div class="counter">54</div>
                </div>
                <h5 class="counter-minimal-title">Qualified Teachers</h5>
              </article>
            </div>
          </div>
        </div>
      </section>

      <!-- Small Features-->
      <section class="section section-lg bg-gray-100">
        <div class="container">
          <div class="row row-30">
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Box Minimal-->
              <article class="box-minimal">
                <div class="box-minimal-icon linearicons-playlist wow fadeIn"></div>
                <div class="box-minimal-main wow-outer">
                  <h4 class="box-minimal-title wow slideInDown">Piano</h4>
                  <p class="wow fadeInUpSmall">Want to learn to play piano? Our Piano Lessons are open to everyone.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Box Minimal-->
              <article class="box-minimal">
                <div class="box-minimal-icon linearicons-guitar wow fadeIn" data-wow-delay=".1s"></div>
                <div class="box-minimal-main wow-outer">
                  <h4 class="box-minimal-title wow slideInDown" data-wow-delay=".1s">Guitar</h4>
                  <p class="wow fadeInUpSmall" data-wow-delay=".1s">Learn to play the world’s popular instrument with our guitar classes.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Box Minimal-->
              <article class="box-minimal">
                <div class="box-minimal-icon linearicons-mic wow fadeIn" data-wow-delay=".2s"></div>
                <div class="box-minimal-main wow-outer">
                  <h4 class="box-minimal-title wow slideInDown" data-wow-delay=".2s">Vocal</h4>
                  <p class="wow fadeInUpSmall" data-wow-delay=".2s">Melody offers a wide variety of vocal classes for all ages and skills.</p>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section>

      <!-- Light 4 Column Layout-->
      <section class="section section-lg text-center">
        <div class="container">
          <h3>Popular Music Classes</h3>
          <p><span class="text-width-1">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</span></p>
          <div class="row row-50 row-xxl-70 offset-top-2">
            <div class="col-sm-6 col-md-4 col-lg-3">
              <!-- Box Light-->
              <article class="box-light">
                <div class="box-light-icon linearicons-playlist"></div>
                <h4 class="box-light-title">Piano</h4>
                <p>Want to learn to play piano? Our Piano Lessons are open to everyone.</p>
              </article>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-3">
              <!-- Box Light-->
              <article class="box-light">
                <div class="box-light-icon linearicons-guitar"></div>
                <h4 class="box-light-title">Guitar</h4>
                <p>Learn to play the world’s popular instrument with our guitar classes.</p>
              </article>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-3">
              <!-- Box Light-->
              <article class="box-light">
                <div class="box-light-icon linearicons-mic"></div>
                <h4 class="box-light-title">Vocal</h4>
                <p>Melody offers a wide variety of vocal classes for all ages and skills.</p>
              </article>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-3">
              <!-- Box Light-->
              <article class="box-light">
                <div class="box-light-icon linearicons-trumpet"></div>
                <h4 class="box-light-title">Trumpet</h4>
                <p>We offer extensive trumpet learning program at our music school.</p>
              </article>
            </div>
          </div>
        </div>
      </section>

      <!-- Stroke Icons 3 Column Layout-->
      <section class="section section-lg bg-gray-100 text-center">
        <div class="container">
          <h3>Featured Music Classes</h3>
          <div class="row row-60">
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Box Creative-->
              <article class="box-creative wow slideInDown" data-wow-delay=".1s">
                <div class="novi-icon box-creative-icon linearicons-playlist"></div>
                <h4 class="box-creative-title"><a href="classes.html">Piano</a></h4>
                <p>Want to learn to play piano? Our Piano Lessons are open to everyone. </p>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Box Creative-->
              <article class="box-creative wow slideInDown" data-wow-delay=".2s">
                <div class="novi-icon box-creative-icon linearicons-guitar"></div>
                <h4 class="box-creative-title"><a href="classes.html">Guitar</a></h4>
                <p>Learn to play the world’s popular instrument with our guitar classes.</p>
              </article>
            </div>
            <div class="col-sm-6 col-lg-4 wow-outer">
              <!-- Box Creative-->
              <article class="box-creative wow slideInDown" data-wow-delay=".3s">
                <div class="novi-icon box-creative-icon linearicons-mic"></div>
                <h4 class="box-creative-title"><a href="classes.html">Vocal</a></h4>
                <p>Melody offers a wide variety of vocal classes for all ages and skills.</p>
              </article>
            </div>
          </div>
        </div>
      </section>

      <!-- Contact Info-->
      <section class="section section-sm">
        <div class="container">
          <div class="layout-bordered">
            <div class="layout-bordered-item wow-outer">
              <div class="layout-bordered-item-inner wow slideInUp">
                <div class="icon icon-lg mdi mdi-phone text-primary"></div>
                <ul class="list-0">
                  <li><a class="link-default" href="tel:#">1-800-1234-678</a></li>
                  <li><a class="link-default" href="tel:#">1-800-9876-098</a></li>
                </ul>
              </div>
            </div>
            <div class="layout-bordered-item wow-outer">
              <div class="layout-bordered-item-inner wow slideInUp">
                <div class="icon icon-lg mdi mdi-email text-primary"></div><a class="link-default" href="mailto:#">info@demolink.org</a>
              </div>
            </div>
            <div class="layout-bordered-item wow-outer">
              <div class="layout-bordered-item-inner wow slideInUp">
                <div class="icon icon-lg mdi mdi-map-marker text-primary"></div><a class="link-default" href="#">2130 Fulton Street San Diego, CA 94117-1080 USA</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- Page Footer-->
            <?php require 'footer.php'; ?>